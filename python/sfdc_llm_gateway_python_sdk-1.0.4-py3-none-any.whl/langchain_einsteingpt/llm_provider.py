import json
import re
from typing import Optional, List, Mapping, Any, Iterator
import time

from langchain_core.outputs import GenerationChunk

import llmgateway_api
from llmgateway_api import ApiTypeError
from llmgateway_api import GenerationRequest
from langchain_core.callbacks.manager import CallbackManagerForLLMRun
from langchain_core.language_models.llms import LLM

from llmgateway_api import GenerationResponse


class EinsteinGPTLLM(LLM):
    sfdc_core_tenant_id: Optional[str] = None
    org_id: Optional[str] = None
    url: str
    access_token: str = None
    ssl_ca_cert: Optional[str] = None
    provider: str = "OpenAI"
    model: str = "text-davinci-003"
    temperature: float = None
    num_generations: int = None
    max_tokens: int = None
    top_p: float = None
    frequency_penalty: float = None
    presence_penalty: float = None
    x_client_feature_id: str = None
    app_context: str = "EinsteinGPT"
    hawking_id: Optional[str] = (
        None  # If both sfdc_core_tenant_id and hawking_id are provided, sfdc_core_tenant_id will be used. hawking_id format:core/falcontest1-core4sdb6/00Dxxxxx.
    )
    mtls_enabled: bool = False
    cert_file: str = None
    key_file: str = None
    region: str = "us-west-2"
    enable_pii_masking: bool = False
    enable_input_safety_scoring: bool = False
    enable_output_safety_scoring: bool = False

    @property
    def headers(self) -> Mapping[str, str]:
        if not self.hawking_id and not self.sfdc_core_tenant_id and not self.org_id:
            raise Exception("Please provide either sfdc_core_tenant_id or hawking_id")

        header = {
            "X-LLM-Provider": self.provider,
            "X-client-feature-id": self.x_client_feature_id,
            "X-Salesforce-Region": self.region,
            "X-sfdc-app-context": self.app_context,
        }

        if self.sfdc_core_tenant_id:
            header["X-sfdc-core-tenant-id"] = self.sfdc_core_tenant_id
            header["X-client-trace-id"] = self.sfdc_core_tenant_id + "_" + str(int(time.time()))
        elif self.org_id:
            header["X-sfdc-core-tenant-id"] = self.org_id
            header["X-client-trace-id"] = self.org_id + "_" + str(int(time.time()))
        else:
            header["X-sfdc-core-tenant-id"] = self.hawking_id
            header["X-client-trace-id"] = self.hawking_id + "_" + str(int(time.time()))

        return header

    @property
    def api_instance(self) -> llmgateway_api.DefaultApi:
        return llmgateway_api.DefaultApi(self.get_api_client())

    def get_gateway_config(self) -> llmgateway_api.Configuration:
        return llmgateway_api.Configuration(
            host=self.url,
            access_token=self.access_token,
            ssl_ca_cert=self.ssl_ca_cert,
        )

    def get_api_client(self) -> llmgateway_api.ApiClient:
        return llmgateway_api.ApiClient(self.get_gateway_config())

    @property
    def _llm_type(self) -> str:
        return "EinsteinGPTLLM"

    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> str:
        request_args = self.build_generate_request_args(stop, **kwargs)
        generation_request = GenerationRequest(**request_args, prompt=prompt)
        generations_api_response = self.api_instance.generations(generation_request, _headers=self.headers)

        return generations_api_response.generations[0].text

    def _stream(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> Iterator[GenerationChunk]:
        request_args = self.build_generate_request_args(stop, **kwargs)
        generation_request = GenerationRequest(**request_args, prompt=prompt)
        api_response = self.api_instance.generations_stream(generation_request, _headers=self.headers)
        yield from self._build_generation_chunks(api_response.response)

    def build_generate_request_args(
        self,
        stop,
        **kwargs: Any,
    ):
        request_args = {}
        parameters = {}
        if stop:
            request_args["stop_sequences"] = stop
        kwargs_max_tokens = kwargs.get("max_tokens", None)
        if self.max_tokens or kwargs_max_tokens:
            request_args["max_tokens"] = kwargs_max_tokens if kwargs_max_tokens else self.max_tokens
        if self.model:
            request_args["model"] = self.model
        kwargs_temperature = kwargs.get("temperature", None)
        if self.temperature or kwargs_temperature:
            request_args["temperature"] = kwargs_temperature if kwargs_temperature else self.temperature
        if self.provider:
            request_args["provider"] = self.provider
        if self.presence_penalty:
            request_args["presence_penalty"] = self.presence_penalty
        if self.frequency_penalty:
            request_args["frequency_penalty"] = self.frequency_penalty
        if self.num_generations:
            request_args["num_generations"] = self.num_generations
        kwargs_top_p = kwargs.get("top_p", None)
        if self.top_p or kwargs.get("top_p", None):
            parameters["top_p"] = kwargs_top_p if kwargs_top_p else self.top_p
        request_args["enable_pii_masking"] = self.enable_pii_masking
        request_args["enable_output_safety_scoring"] = self.enable_output_safety_scoring
        request_args["enable_input_safety_scoring"] = self.enable_input_safety_scoring
        request_args["parameters"] = parameters
        return request_args

    @property
    def _identifying_params(self) -> Mapping[str, Any]:
        """Get the identifying parameters."""
        return {
            "provider": self.provider,
            "sfdc_core_tenant_id": self.sfdc_core_tenant_id,
            "url": self.url,
            "access_token": self.access_token,
            "ssl_ca_cert": self.ssl_ca_cert,
            "model": self.model,
            "temperature": self.temperature,
            "num_generations": self.num_generations,
            "max_tokens": self.max_tokens,
            "top_p": self.top_p,
            "frequency_penalty": self.frequency_penalty,
            "presence_penalty": self.presence_penalty,
            "enable_output_safety_scoring": self.enable_output_safety_scoring,
            "enable_pii_masking": self.enable_pii_masking,
            "enable_input_safety_scoring": self.enable_input_safety_scoring
        }

    def _build_generation_chunks(self, generations_api_response):
        """
        This method builds GenerationChunk from generated byte response
        """
        pattern = re.compile(r"(?:event:\s*(\w+)\s*[\\n]+data:\s*([{|\[].*?[}|\]])[\\n]+)")
        for line in generations_api_response.stream(decode_content=True):
            decoded_line = line.decode("utf-8")
            # Find all matches in the decoded line
            for matched_groups in pattern.finditer(decoded_line):
                # Process only if the event is "generation"
                event = matched_groups.group(1)
                data = matched_groups.group(2)
                if self.__is_generation_event(event) and not self.__is_end_token(data):
                    # Parse JSON data to a GenerationResponse object
                    generations_api_responses = json.loads(data)
                    for generations_api_response in generations_api_responses.get("generations"):
                        if generations_api_response.get("text"):
                            # Yield a GenerationChunk object with text and generation info
                            yield GenerationChunk(text=generations_api_response.get("text"),
                                                  generation_info=generations_api_response.get("parameters"))

    def __is_generation_event(self, event):
        return event == "generation"

    def __is_end_token(self, data):
        return data == "[DONE]"

