"""Wrapper around LLM Gateway embedding models."""

import os
from typing import Any, Dict, List, Optional, Union

import requests

from langchain.embeddings.base import Embeddings
from langchain.utils import get_from_dict_or_env


class EinsteinGPTEmbeddings(Embeddings):
    api_token: str = None
    x_client_feature_id: str = None

    # These have sane defaults in __init__
    api_url: Optional[str] = None
    llm_provider: Optional[str] = None
    model: Optional[str] = None
    sfdc_core_tenant_id: Optional[str] = None  # If both sfdc_core_tenant_id and hawking_id are provided, sfdc_core_tenant_id will be used
    org_id: Optional[str] = None
    hawking_id: Optional[str] = None
    hawking_app_type: Optional[str] = None
    enable_pii_masking: Optional[bool] = None
    ssl_ca_cert: Optional[str] = None

    # LLM Gateway does not appear to support the "user" API argument.
    # The following embeddings endpoint headers are not supported:
    # - X-Request-Id
    # - X-B3-TraceId
    # - X-B3-SpanId
    # - X-B3-ParentSpanId

    def __init__(self, **kwargs):
        # Required, will raise exception if missing:
        self.api_token = get_from_dict_or_env(kwargs, "api_token", "LLM_API_KEY")
        self.x_client_feature_id = get_from_dict_or_env(kwargs, "x_client_feature_id", "X_CLIENT_FEATURE_ID")

        # Sane Defaults:
        self.api_url = get_from_dict_or_env(
            kwargs,
            "api_url",
            "LLM_GATEWAY_API_URL",
            default="https://bot-svc-llm.sfproxy.einsteintest1.test1-uswest2.aws.sfdc.cl",
        )
        self.llm_provider = get_from_dict_or_env(kwargs, "llm_provider", "LLM_GATEWAY_PROVIDER", default="OpenAI")
        self.model = get_from_dict_or_env(kwargs, "model", "LLM_GATEWAY_MODEL", default="text-embedding-ada-002")
        self.sfdc_core_tenant_id = self._get_from_dict_or_env_else_none(kwargs, "sfdc_core_tenant_id", "LLM_GATEWAY_ORG_ID")
        self.hawking_id = self._get_from_dict_or_env_else_none(kwargs, "hawking_id", "LLM_GATEWAY_HAWKING_ID")
        self.hawking_app_type = self._get_from_dict_or_env_else_none(
            kwargs, "hawking_app_type", "LLM_GATEWAY_HAWKING_APP_TYPE"
        )
        self.enable_pii_masking = bool(
            self._get_from_dict_or_env_else_none(
                kwargs, "enable_pii_masking", "LLM_GATEWAY_ENABLE_PII_MASKING", default="false"
            )
        )
        self.ssl_ca_cert = self._get_from_dict_or_env_else_none(
            kwargs, "ssl_ca_cert", "LLM_GATEWAY_SSL_CA_CERT", default="Salesforce_Internal_Root_CA_3.pem"
        )

        if self.llm_provider not in ["OpenAI", "Cohere", "InternalTextGeneration", "InternalCodeGeneration"]:
            raise Exception("Invalid llm_provider provided.")
        if (not self.hawking_id) and (not self.sfdc_core_tenant_id) and (not self.org_id):
            raise Exception("Must provide either hawking_id or sfdc_core_tenant_id to EinsteinGPTEmbeddings during initialization")

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Call out to LLM Gateway's embedding endpoint.
        Args:
            texts: The list of texts to embed.
        Returns:
            List of embeddings, one for each text.
        """
        response = self._post(texts)
        json = response.json()
        usage = json.get("parameters").get("usage")
        print(f"OpenAI Usage: {usage}")
        embeddings = json.get("embeddings")
        embedding_data = [embedding.get("embedding") for embedding in embeddings]
        result = [list(map(float, e)) for e in embedding_data]
        return result

    def embed_query(self, text: str) -> List[float]:
        """Call out to LLM Gateway's embedding endpoint.
        Args:
            text: The text to embed.
        Returns:
            Embeddings for the text.
        """
        response = self._post([text])
        json = response.json()
        usage = json.get("parameters").get("usage")
        print(f"OpenAI Usage: {usage}")
        embedding = json.get("embeddings")[0]["embedding"]
        return list(map(float, embedding))

    @property
    def _embeddings_url(self):
        return f"{self.api_url}/v1.0/embeddings"

    def validate_environment(self, values: Dict) -> Dict:
        try:
            resp = requests.get(f"{self.api_url}/v1.0/models", headers=self._headers(), verify=self.ssl_ca_cert)

            if resp.status_code == 401:
                raise ValueError("The given LLM GW auth token is invalid. " "Please check your LLM GW auth token.")
            resp.raise_for_status()

        except requests.exceptions.HTTPError as err:
            raise ValueError(f"Error: {err!r}")
        return values

    def _post(self, texts: List[str], **kwargs: Any) -> requests.Response:
        embedding_url = self._embeddings_url
        data = self._post_data_for(texts)
        headers = self._headers()
        response = requests.post(embedding_url, json=data, headers=headers, verify=self.ssl_ca_cert, **kwargs)
        return response

    def _post_data_for(self, texts):
        data = {
            "input": texts,
            "model": self.model,
        }
        if self.enable_pii_masking is not None:
            data["enable_pii_masking"] = self.enable_pii_masking
        return data

    def _headers(self):
        headers = {
            "Authorization": self._auth_header(),
            "X-LLM-Provider": self.llm_provider,
            "Accept": "application/json",
            "content-type": "application/json",
            "x-client-feature-id": self.x_client_feature_id,
        }
        if self.sfdc_core_tenant_id:
            headers["X-sfdc-core-tenant-id"] = self.sfdc_core_tenant_id
        elif self.org_id:
            headers["X-sfdc-core-tenant-id"] = self.org_id
        elif self.hawking_id:
            headers["X-Tenant-Id"] = self.hawking_id
            if self.hawking_app_type:
                headers["X-Hawking-appType"] = self.hawking_app_type
        return headers

    def _auth_header(self):
        if self.api_token and len(self.api_token.split(" ")) > 1:
            return self.api_token
        else:
            return f"API_KEY " + self.api_token

    @staticmethod
    def _get_from_dict_or_env_else_none(
        data: Dict[str, Any], key: str, env_key: str, default: Optional[str] = None
    ) -> Union[str, None]:
        """Get a value from a dictionary or an environment variable."""
        if key in data and data[key] is not None:
            return data[key]
        elif env_key in os.environ and os.environ[env_key]:
            return os.environ[env_key]
        elif default is not None:
            return default
        return None
