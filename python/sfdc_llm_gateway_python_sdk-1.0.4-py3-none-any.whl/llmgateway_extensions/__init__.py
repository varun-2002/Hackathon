__version__ = "1.0.4"

from llmgateway_extensions.configuration import ConfigurationLLMGateway

