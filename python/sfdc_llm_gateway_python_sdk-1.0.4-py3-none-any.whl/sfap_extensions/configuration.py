from typing import Optional
import sfap_api

class ConfigurationSfap(sfap_api.Configuration):
    """The purpose of this class is to support mTLS.
    
    These arguments do not exist in the base class constructor.
    :param cert_file: str - the path to a client certificate file
    :param key_file: str - the path to a client key file

    The corresponding class variables are initialized in this class.
    """

    def __init__(self, host=None,
                 api_key=None, api_key_prefix=None,
                 username=None, password=None,
                 access_token=None,
                 server_index=None, server_variables=None,
                 server_operation_index=None, server_operation_variables=None,
                 ignore_operation_servers=False,
                 ssl_ca_cert=None,
                 cert_file=None,
                 key_file=None,
                 retries=None,
                 *,
                 debug: Optional[bool] = None
                 ) -> None:

        # Call the base Constructor
        super().__init__(
            host,
            api_key, api_key_prefix,
            username, password,
            access_token,
            server_index, server_variables,
            server_operation_index, server_operation_variables,
            ignore_operation_servers,
            ssl_ca_cert,
            retries,
            debug=debug
        )

        # client certificate file
        self.cert_file = cert_file

        # client key file
        self.key_file = key_file

