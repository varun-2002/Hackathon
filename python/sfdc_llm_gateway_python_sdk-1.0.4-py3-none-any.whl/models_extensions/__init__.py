__version__ = "1.0.4"

from models_extensions.configuration import ConfigurationModels

